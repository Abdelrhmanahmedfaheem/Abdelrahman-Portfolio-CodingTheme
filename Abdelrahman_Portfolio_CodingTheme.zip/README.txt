ABDELRAHMAN AHMED FAHEEM — SPIDER-MAN INSPIRED AI PORTFOLIO

Updated portfolio includes:
- Real certificates supplied by the owner.
- Placeholder slots for DEBI and Java Programming certificates until images are available.
- Updated email, phone, LinkedIn and GitHub links.
- Expanded AI/LLM skills: RAG, LLMs, Llama 3 70B, JSON, QLoRA, LoRA, OCR, STT/TTS and FastAPI.
- Arab Open University (AOU) added to the About section.
- More visible white spider-web cursor effect and custom spider cursor.
- Certificate medals suspended with web-style hangers.
- Mobile, accessibility and reduced-motion improvements.

Final update: restored the original simple name treatment and rebuilt the hero portrait hanging web so all suspension strands converge at one overhead point with a smoother free-swing motion.

- Replaced the generated hanging-web SVG with the user-supplied spider-web design, extracted onto transparency so it visibly holds the portrait.
